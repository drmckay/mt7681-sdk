/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm.util;

public class Conf {
	// Auth Mode
	public static final byte AuthModeOpen = 0x00;
	public static final byte AuthModeShared = 0x01;
	public static final byte AuthModeAutoSwitch = 0x02;
	public static final byte AuthModeWPA = 0x03;
	public static final byte AuthModeWPAPSK = 0x04;
	public static final byte AuthModeWPANone = 0x05;
	public static final byte AuthModeWPA2 = 0x06;
	public static final byte AuthModeWPA2PSK = 0x07;
	public static final byte AuthModeWPA1WPA2 = 0x08;
	public static final byte AuthModeWPA1PSKWPA2PSK = 0x09;
	
	//Network type
	public static final int LAN =0;
	public static final int WLAN =1;
	
	public static final String SERVER_IP_IN_LAN_MODE ="182.148.123.91";
	public static final int DEFAULT_LIGHT_COLOR = 0xFFFF0000;//默认为红色
	
	public static final String KEY_NETWORK_TYPE ="network_type";
	public static final String KEY_SERVER_IP ="server_ip";
}
