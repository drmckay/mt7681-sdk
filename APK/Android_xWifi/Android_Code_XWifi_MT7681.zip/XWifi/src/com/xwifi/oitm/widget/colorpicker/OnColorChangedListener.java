/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm.widget.colorpicker;
public interface OnColorChangedListener {
        void onColorChanged(int color);
    }