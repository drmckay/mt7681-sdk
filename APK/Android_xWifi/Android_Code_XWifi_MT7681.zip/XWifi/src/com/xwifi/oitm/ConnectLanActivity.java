/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm;

import java.lang.reflect.Field;
import java.util.List;

import mediatek.android.IoTManager.IoTManagerNative;

import com.xwifi.oitm.R;
import com.xwifi.oitm.util.Conf;
import com.xwifi.oitm.util.Utils;
import com.xwifi.oitm.util.XWifiLog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConnectLanActivity extends Activity {
	private static final String TAG = ConnectLanActivity.class.getName();

	private TextView mButtonStart;
	private EditText mEditSSID;
	private EditText mPwdET;
	private EditText mIPET;
	private View mIPLL;
	private IoTManagerNative IoTManager;
	private WifiManager mWifiManager;
	private String mConnectedSsid;
	private String mAuthString;
	private String  mServerIp;
	private byte mAuthMode;
	private Activity mActivity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.connect_lan_layout);
		mActivity =this;
		IoTManager = new IoTManagerNative();
		initView();
		setConnectedSsidParameter();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add("Set server ip");
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		showInputServerIpDialog();
		return super.onOptionsItemSelected(item);
	}
	
	private void showInputServerIpDialog(){
		AlertDialog.Builder builder =new AlertDialog.Builder(this);
		builder.setTitle("Please input server ip");
		final EditText ipET =new EditText(this);
		ipET.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		ipET.setHint("xxx.xxx.xxx.xxx");
		builder.setView(ipET);
		final AlertDialog dialog =builder.create();
		builder.setPositiveButton("OK", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String inputIP =ipET.getText().toString().trim();
				if(Utils.isIPAdress(inputIP)){
					mServerIp =inputIP;
					XWifiLog.showToast(mActivity, "Server ip set successfully, please connect!");
					setDialogDismiss(dialog, true);
				}else{
					XWifiLog.showToast(mActivity, "Invalid ip address, please try again!");
					setDialogDismiss(dialog, false); 
				}
			}
		});
		builder.setNegativeButton("Cancel", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				setDialogDismiss(dialog, true); 
			}
		});
		builder.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if(KeyEvent.KEYCODE_BACK == keyCode){
					mButtonStart.setEnabled(true);
					setDialogDismiss(dialog, true);
				}
				return false;
			}
		});
		builder.show();
	}
	
	private void setDialogDismiss(DialogInterface dialog, boolean dismiss){
		try {
            Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing"); 
            field.setAccessible(true);
            field.set(dialog, dismiss);
        } catch (Exception e) { 
            e.printStackTrace();
        } 
	}

	private void initView() {
		mIPLL = findViewById(R.id.ip_ll);
		mIPET = (EditText) findViewById(R.id.ip_tv);
		mIPET.setText(Utils.getDefaultLanServerIp());
		mPwdET = (EditText) findViewById(R.id.pwd_tv);
		//mPwdET.addTextChangedListener(mTextWatcher);
		mButtonStart = (TextView) findViewById(R.id.start_connect_btn);
		mEditSSID = (EditText) findViewById(R.id.ssid_tv);
		mButtonStart.setOnClickListener(mButtonStartListener);
	}
	
	TextWatcher mTextWatcher = new TextWatcher() {
        @Override  
        public void onTextChanged(CharSequence s, int start, int before, int count) {  
            if(s.length() > 0){
            	mIPLL.setVisibility(View.VISIBLE);
            }else{
            	mIPLL.setVisibility(View.GONE);
            }
        }  
          
        @Override  
        public void beforeTextChanged(CharSequence s, int start, int count,  
                int after) {  
            // TODO Auto-generated method stub  
        }  
          
        @Override  
        public void afterTextChanged(Editable s) {  
            // TODO Auto-generated method stub 
        }  
    };  

	Button.OnClickListener mButtonStartListener = new Button.OnClickListener() {

		public void onClick(View view) {
			String SSID = mEditSSID.getText().toString();
			String pwd = mPwdET.getText().toString();
			int networkType = Conf.LAN;
			XWifiLog.w(TAG, "Smart connection with : ssid = " + SSID
					+ " Password = " + pwd);
			/*if(!pwd.equals("")){
				mServerIp =mIPET.getText().toString();
				networkType =Conf.WLAN;
				if(!Utils.isIPAdress(mServerIp)){
					XWifiLog.showToast(mActivity, "Invalid ip address, please try again!");
					return;
				}
			}*/
			mButtonStart.setEnabled(false);
			int ret = IoTManager.StartSmartConnection(SSID, pwd,
					(byte) mAuthMode);
			XWifiLog.w(TAG, "ret:" + ret);
			if (ret >= 0) {
				Intent mIntent =new Intent(ConnectLanActivity.this, LightControlActivity.class);
				//Set default server ip and network type
				mIntent.putExtra(Conf.KEY_SERVER_IP, mServerIp);
				mIntent.putExtra(Conf.KEY_NETWORK_TYPE, networkType);
				XWifiLog.i(TAG , "server_ip:" + mServerIp + " , network_type:" + networkType);
				ConnectLanActivity.this.startActivity(mIntent);
				finish();
			}
		}
	};

	private void setConnectedSsidParameter() {
		// Get Authentication mode of AP
		mWifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		if (mWifiManager.isWifiEnabled()) {
			WifiInfo WifiInfo = mWifiManager.getConnectionInfo();
			mConnectedSsid = WifiInfo.getSSID();
			int iLen = mConnectedSsid.length();
			if (mConnectedSsid.startsWith("\"")
					&& mConnectedSsid.endsWith("\"")) {
				mConnectedSsid = mConnectedSsid.substring(1, iLen - 1);
			}
			mEditSSID.setText(mConnectedSsid);
			XWifiLog.d(TAG, "SSID = " + mConnectedSsid);
			
			mServerIp = Utils.getDefaultLanServerIp();
			XWifiLog.d(TAG, "Server Ip = " + mServerIp);
			
			List<ScanResult> ScanResultlist = mWifiManager.getScanResults();
			for (int i = 0, len = ScanResultlist.size(); i < len; i++) {
				ScanResult AccessPoint = ScanResultlist.get(i);

				if (AccessPoint.SSID.equals(mConnectedSsid)) {
					boolean WpaPsk = AccessPoint.capabilities
							.contains("WPA-PSK");
					boolean Wpa2Psk = AccessPoint.capabilities
							.contains("WPA2-PSK");
					boolean Wpa = AccessPoint.capabilities.contains("WPA-EAP");
					boolean Wpa2 = AccessPoint.capabilities
							.contains("WPA2-EAP");

					if (AccessPoint.capabilities.contains("WEP")) {
						mAuthString = "OPEN-WEP";
						mAuthMode = Conf.AuthModeOpen;
						break;
					}

					if (WpaPsk && Wpa2Psk) {
						mAuthString = "WPA-PSK WPA2-PSK";
						mAuthMode = Conf.AuthModeWPA1PSKWPA2PSK;
						break;
					} else if (Wpa2Psk) {
						mAuthString = "WPA2-PSK";
						mAuthMode = Conf.AuthModeWPA2PSK;
						break;
					} else if (WpaPsk) {
						mAuthString = "WPA-PSK";
						mAuthMode = Conf.AuthModeWPAPSK;
						break;
					}

					if (Wpa && Wpa2) {
						mAuthString = "WPA-EAP WPA2-EAP";
						mAuthMode = Conf.AuthModeWPA1WPA2;
						break;
					} else if (Wpa2) {
						mAuthString = "WPA2-EAP";
						mAuthMode = Conf.AuthModeWPA2;
						break;
					} else if (Wpa) {
						mAuthString = "WPA-EAP";
						mAuthMode = Conf.AuthModeWPA;
						break;
					}

					mAuthString = "OPEN";
					mAuthMode = Conf.AuthModeOpen;
				}
			}
			XWifiLog.d(TAG, "Auth Mode = " + mAuthString);
		}
	}
}
