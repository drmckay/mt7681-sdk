/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm.util;

import java.util.regex.Pattern;

public class Utils {
	public static String intToIp(int i) {
		return ((i >> 24) & 0xFF) + "." + ((i >> 16) & 0xFF) + "."
				+ ((i >> 8) & 0xFF) + "." + (i & 0xFF);
	}

	public static String parseServerIp(int i) {
		return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF)
				+ "." + 1;// default xxx.xxx.xxx.1
	}

	public static String getDefaultLanServerIp() {
		return Conf.SERVER_IP_IN_LAN_MODE;
	}

	//Judge if it is valid ip address
	public static boolean isIPAdress(String str) {
		Pattern pattern = Pattern
				.compile("^((\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5]|[*])\\.){3}(\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5]|[*])$");
		return pattern.matcher(str).matches();
	}

}
