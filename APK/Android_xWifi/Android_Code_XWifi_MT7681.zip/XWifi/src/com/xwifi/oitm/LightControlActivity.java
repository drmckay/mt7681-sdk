/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm;

import mediatek.android.IoTManager.ClientInfo;
import mediatek.android.IoTManager.IoTManagerNative;

import com.xwifi.oitm.R;
import com.xwifi.oitm.util.Conf;
import com.xwifi.oitm.util.RgbUtils;
import com.xwifi.oitm.util.XWifiLog;
import com.xwifi.oitm.widget.colorpicker.ColorPickerView;
import com.xwifi.oitm.widget.colorpicker.OnColorChangedListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;

public class LightControlActivity extends Activity implements
		OnColorChangedListener {
	public static final String TAG = LightControlActivity.class.getName();
	public static final int MSG_INIT_SERVER_ERROR = 1;
	public static final int MSG_QUERY_CLIENT_COMPLETE = 2;
	public static final int MSG_QUERY_CLIENT_ERROR = 3;
	public static final int MSG_GET_HUMTEMP_FINISHED =4;
	public static final int MSG_SWITCH_LIGHT_FINISHED =5;

	private TextView mColorView;
	private ColorPickerView mPickerViewDialog;
	private ToggleButton mLightTB;
	private RadioButton mLightShowingRB;
	private TextView mTempShowingTV;
	private TextView mColorShowingDialogTV;
	private TextView mHumidityShowingTV;
	private TextView mTempBtn;
	private TextView mColorPickerBtn;

	private IoTManagerNative managerNative;
	private int mClientID;
	private int mCurrentColor = Conf.DEFAULT_LIGHT_COLOR;
	private Activity mActivity;
	private String mServerIp;
	private int mNetworkType;
	private ProgressDialog mLoading;
	private ClientInfo mClient;

	public LightControlActivity() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.light_color_picker_layout);
		mActivity = this;
		mServerIp = this.getIntent().getStringExtra(Conf.KEY_SERVER_IP);
		mNetworkType = this.getIntent().getIntExtra(Conf.KEY_NETWORK_TYPE,
				Conf.LAN);
		managerNative = IoTManagerNative.getInstance();
		tryToInitServer();
		initViews();
	}

	@Override
	protected void onDestroy() {
		managerNative.StopSmartConnection2();
		System.exit(0);
	}

	public Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			if (mLoading != null && !mActivity.isFinishing()) {
				mLoading.dismiss();
			}
			switch (msg.what) {
			case MSG_INIT_SERVER_ERROR:
				XWifiLog.showToast(mActivity,
						"Init server error, please reconnect the server again!");
				break;
			case MSG_QUERY_CLIENT_COMPLETE:
				XWifiLog.showToast(mActivity, "get clients successfully"
						+ ", clientid:" + mClient.ClientID + ", ip:"
						+ mClient.IPAddress);
				int[] rgb = managerNative.GetPWM(mClient.ClientID);
				if (rgb.length == 3) {
					int myColor = RgbUtils.getRGBColor(rgb);
					setRGBToNative(myColor);
				}
				int[] gpio = managerNative.GetGPIO(mClient.ClientID);
				if (gpio.length == 2) {
					mLightTB.setChecked(gpio[1] == 1 ? true : false);
				}
				break;
			case MSG_QUERY_CLIENT_ERROR:
				XWifiLog.showToast(mActivity,
						"Can't get clients, please reconnect the server again!");
				break;
			case MSG_GET_HUMTEMP_FINISHED:
				String hum =(msg.arg1>>8) + "." + (msg.arg1&0xFF) + "%";
				String temp =(msg.arg2>>8) + "." + (msg.arg2&0xFF) + "℃";
				mTempShowingTV.setText(temp);
				mHumidityShowingTV.setText(hum);
				mTempBtn.setEnabled(true);
				break;
				
			case MSG_SWITCH_LIGHT_FINISHED:
				mLightTB.setEnabled(true);
				break;
			}
		}
	};

	public void tryToInitServer() {
		mLoading = new ProgressDialog(mActivity);
		mLoading.setMessage("Trying to init server, please wait ...");
		mLoading.show();

		new Thread(new Runnable() {
			@Override
			public void run() {
				int ret = managerNative.InitControlServer(mServerIp,
						mNetworkType);
				int ret2 = managerNative.InitCtrlPassword("");// Init password
				XWifiLog.e(TAG, "InitControlServer ret:" + ret);
				if (ret >= 0 && ret2 >= 0) {
					ClientInfo[] clientList = managerNative
							.QueryClientInfo(mNetworkType);
					if (clientList.length > 0) {
						mClient = clientList[0];
						mClientID = mClient.ClientID;
						mHandler.sendEmptyMessage(MSG_QUERY_CLIENT_COMPLETE);
					} else {
						mHandler.sendEmptyMessage(MSG_QUERY_CLIENT_ERROR);
					}
				} else {
					mHandler.sendEmptyMessage(MSG_INIT_SERVER_ERROR);
				}
			}
		}).start();
	}

	private void initViews() {
		mTempShowingTV = (TextView) this.findViewById(R.id.temp_showing_tv);
		mHumidityShowingTV =(TextView) this.findViewById(R.id.humidity_showing_tv);
		mTempBtn = (TextView) this.findViewById(R.id.temp_btn);
		mTempBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mTempBtn.setEnabled(false);
				new Thread(new Runnable() {
					public void run() {
						int[] humTemp = getHUMTEMP();
						if(humTemp !=null && humTemp.length ==2){
							Message msg =mHandler.obtainMessage(MSG_GET_HUMTEMP_FINISHED, humTemp[0], humTemp[1]);
							mHandler.sendMessage(msg);
						}else{
							Message msg =mHandler.obtainMessage(MSG_GET_HUMTEMP_FINISHED, 0, 0);
							mHandler.sendMessage(msg);
						}
					}
				}).start();
			}
		});
		mLightShowingRB = (RadioButton) this
				.findViewById(R.id.light_showing_rb);
		mLightTB = (ToggleButton) this.findViewById(R.id.light_switch_tb);
		mLightTB.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					final boolean isChecked) {
				mLightShowingRB.setChecked(isChecked);
				mLightTB.setEnabled(false);
				new Thread(new Runnable() {
					public void run() {
						if (isChecked) {
							turnOn();
						} else {
							turnOff();
						}
						mHandler.sendEmptyMessage(MSG_SWITCH_LIGHT_FINISHED);
					}
				}).start();
			}
		});

		mColorView = (TextView) this.findViewById(R.id.light_color_view);
		mColorView.setBackgroundColor(Conf.DEFAULT_LIGHT_COLOR);
		mColorView.setText(RgbUtils.toHexRGBString(mCurrentColor));
		mColorPickerBtn = (TextView) this.findViewById(R.id.color_picker_btn);
		mColorPickerBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showColorPickerDialog(mCurrentColor);
			}
		});
	}

	private void showColorPickerDialog(int defaultColor) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		View mDialogView = LayoutInflater.from(this).inflate(
				R.layout.light_color_picker_dialog_layout, null);
		mPickerViewDialog = (ColorPickerView) mDialogView
				.findViewById(R.id.light_color_picker_dialog);
		mPickerViewDialog.setOnColorChangedListener(this);
		mColorShowingDialogTV = (TextView) mDialogView
				.findViewById(R.id.light_color_view_dialog);
		showColorViews(defaultColor);
		builder.setView(mDialogView);
		builder.show();
	}

	private void setRGBToNative(int color) {
		mCurrentColor = color;
		showColorViews(mCurrentColor);
		int id = mClientID;
		int[] rgb = RgbUtils.getRGB(mCurrentColor);
		// XWifiLog.showToast(mActivity, "changed rgb:(" + rgb[0] + "," + rgb[1]
		// + "," + rgb[2]+")" + "myColor:" + mCurrentColor);
		short bigR = (short) (rgb[0] * (1 << 8));
		short bigG = (short) (rgb[1] * (1 << 8));
		short bigB = (short) (rgb[2] * (1 << 8));
		managerNative.SetPWM(id, bigR, bigG, bigB);
	}
	
	private void showColorViews(int color){
		if(mPickerViewDialog !=null){
			mPickerViewDialog.setCenterColor(color);
		}
		if (mColorShowingDialogTV != null) {
			mColorShowingDialogTV.setBackgroundColor(color);
			mColorShowingDialogTV.setText(RgbUtils.toHexRGBString(color));
		}
		if(mColorView !=null){
			mColorView.setBackgroundColor(color);
			mColorView.setText(RgbUtils.toHexRGBString(color));
		}
	}

	/**
	 * Turn off light
	 * GPIO4 low,keep GPIO0 with High,since we take GPIO0 as a communication port for temperature and humidity sensor.
	 */
	public void turnOff() {
		XWifiLog.i(TAG, "Turn Off");
		managerNative.SetGPIO(mClientID, ((1<<4)|(1<<0)), ((0<<4)|(1<<0)));
	}

	/**
	 * Turn on light
	 * GPIO4 high,keep GPIO0 with High
	 */
	public void turnOn() {
		XWifiLog.i(TAG, "Turn On");
		managerNative.SetGPIO(mClientID, ((1<<4)|(1<<0)), ((1<<4)|(1<<0)));
	}

	@Override
	public void onColorChanged(int color) {
		setRGBToNative(color);
	}

	public int getTemperature() {
		int temp = managerNative.GetTEMP(mClientID);
		XWifiLog.i(TAG, "Get temperature:" + temp);
		return temp;
	}
	
	public int[] getHUMTEMP() {
		return managerNative.GetHUMTEMP(mClientID);
	}
}