/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm.util;

public class RgbUtils {
	public static String toHexRGBString(int color){
		return toHexRGBString(getRGB(color));
	}
	
	public static String toHexARGBString(int color){
		return toHexARGBString(getARGB(color));
	}
	
	public static String toHexRGBString(int[] rgb){
		return toHexRGBString(rgb[0], rgb[1], rgb[2]);
	}
	public static String toHexARGBString(int[] argb){
			return toHexARGBString(argb[0], argb[1], argb[2], argb[3]);
	}
	
	public static String toHexARGBString(int alpha, int r, int g, int b) {
		return "#" + toBrowserHexValue(alpha) + toBrowserHexValue(r) + toBrowserHexValue(g)
				+ toBrowserHexValue(b);
	}
	
	public static String toHexRGBString(int r, int g, int b) {
		return "#" + toBrowserHexValue(r) + toBrowserHexValue(g)
				+ toBrowserHexValue(b);
	}

	private static String toBrowserHexValue(int number) {
		StringBuilder builder = new StringBuilder(
				Integer.toHexString(number & 0xFF));
		while (builder.length() < 2) {
			builder.append("0");
		}
		return builder.toString().toUpperCase();
	}
	
	public static int getRGBColor(int[] rgb){
		return (0xFF<<24) + (rgb[0]<<16) + (rgb[1]<<8) + rgb[2];
	}
	
	public static int getARGBColor(int[] argb){
		return (argb[0]<<24) + (argb[0]<<16) + (argb[1]<<8) + argb[2];
	}
	
	public static int[] getRGB(int color){
		int r = (color>>16) & 0xFF;
		int g = (color>>8) & 0xFF;
		int b = (color) & 0xFF;
		return new int[]{r, g, b};
	}
	
	public static int[] getARGB(int color){
		int alpha = (color>>24) & 0xFF;
		int r = (color>>16) & 0xFF;
		int g = (color>>8) & 0xFF;
		int b = (color) & 0xFF;
		return new int[]{alpha, r, g, b};
	}
}
