/**
 * @author Kevin Zhu
 * @date  2014-10-31
 * @email kevin200728@hotmail.com
 */

package com.xwifi.oitm.util;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class XWifiLog {
	public static final boolean ISDEBUG =true;
	
	public static void e(String tag, String msg){
		if(ISDEBUG){
			Log.e(tag, msg);
		}
	}
	
	public static void w(String tag, String msg){
		if(ISDEBUG){
			Log.w(tag, msg);
		}
	}
	
	public static void i(String tag, String msg){
		if(ISDEBUG){
			Log.i(tag, msg);
		}
	}
	
	public static void d(String tag, String msg){
		if(ISDEBUG){
			Log.d(tag, msg);
		}
	}
	
	public static void showToast(Context context, String msg){
		Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
	}
}
