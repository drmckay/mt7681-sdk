typedef unsigned char UINT8;
typedef unsigned int UINT;
typedef unsigned int UINT32;
typedef void VOID;
typedef unsigned long long  UINT64;