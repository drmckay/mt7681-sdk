/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 *
 * MediaTek Inc. (C) 2010. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/* //device/libs/android_runtime/android_media_MediaPlayer.cpp
 **
 ** Copyright 2007, The Android Open Source Project
 **
 ** Licensed under the Apache License, Version 2.0 (the "License");
 ** you may not use this file except in compliance with the License.
 ** You may obtain a copy of the License at
 **
 **     http://www.apache.org/licenses/LICENSE-2.0
 **
 ** Unless required by applicable law or agreed to in writing, software
 ** distributed under the License is distributed on an "AS IS" BASIS,
 ** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ** See the License for the specific language governing permissions and
 ** limitations under the License.
 */

//#define HWTEST_LOG_NDEBUG 0
//#define HWTEST_LOG_TAG "emBtTest-JNI"
//#include "utils/Log.h"


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <limits.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
//#include <utils/threads.h>
#include <dlfcn.h>
#include <string.h>
#include "jni.h"
//#include "JNIHelp.h"
//#include "android_runtime/AndroidRuntime.h"
//#include "utils/Errors.h"  // for status_t
#undef HWTEST_LOG_NDEBUG
#undef NDEBUG

#include "hwtest_log.h"

#ifdef HWTEST_LOG_TAG
#undef HWTEST_LOG_TAG
#define HWTEST_LOG_TAG "Smart_Connection_JNI"
#endif
extern "C"{
#include "SmartConnection.h"
#include "IoTControl.h"
}
//#include <cutils/sockets.h>
//#include <cutils/properties.h>
//#include <cutils/log.h>

// ----------------------------------------------------------------------------

//using namespace android;

// ----------------------------------------------------------------------------
extern "C"{

jint Java_mediatek_android_IoTManager_IoTManagerNative_StartSmartConnection(JNIEnv *env, jobject thiz, jstring nSSID, jstring nPassword, jbyte nAuth)
{
	int iRst = 0;
	const char *pSSID = NULL;
	const char *pPassword = NULL;

	pSSID = env->GetStringUTFChars(nSSID, 0);
	pPassword = env->GetStringUTFChars(nPassword, 0);

	iRst = StartSmartConnection(pSSID, pPassword, (char)nAuth);
	if (iRst != 0)
	{
		HWTEST_LOGD("StartSmartConnection error.");
	}
	HWTEST_LOGD("Leave Java_mediatek_android_IoTManager_IoTManagerNative_StartSmartConnection.");
	return iRst;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_StopSmartConnection(JNIEnv *env, jobject thiz)
{
	int iRst = 0;
	iRst = StopSmartConnection();
	if (iRst != 0)
	{
		HWTEST_LOGD("StopSmartConnection error.");
	}
	return iRst;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_InitControlServer(JNIEnv *env, jobject thiz, jstring jIPAddr, jint jServType)
{
	int iRet = 0;
	const char *pIPAddr = NULL;

	pIPAddr = env->GetStringUTFChars(jIPAddr, 0);
	HWTEST_LOGD("InitControlServer() type = %d. [%s].", jServType, pIPAddr);

	//0 means Use broadcast to send message
	if (0 == jServType)
	{
		iRet = InitDeviceDiscoveryServer();
	}
	else
	{
		iRet = InitInternetControlServer(pIPAddr);
	}
	if (iRet < 0)
	{
		HWTEST_LOGD("InitControlServer() error.");
		return iRet;
	}

	return iRet;
}
#if 1
jobjectArray Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo(JNIEnv *env, jobject thiz, jint jServType)
{
	unsigned int iClientNum = 0;
	ClientInfo *pClientList = NULL;
	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo.");

	pClientList = QueryClientInfo(&iClientNum, jServType);
	HWTEST_LOGD("QueryClientInfo : [%d] Clients", iClientNum);

	if (0 == iClientNum)
	{
		HWTEST_LOGD("QueryClientInfo : No Clients Connected");
	}

	jclass objClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");
	jobjectArray ClientList = env->NewObjectArray((jsize)iClientNum, objClass, 0);

	jclass objectClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");

	if (NULL == objectClass)
	{
		HWTEST_LOGD("objectClass is null");
	}
	jfieldID ClientIDFiledID = env->GetFieldID(objectClass, "ClientID", "I");
	jfieldID VendorNameFiledID = env->GetFieldID(objectClass, "VendorName", "Ljava/lang/String;");
	jfieldID ProductTypeFiledID = env->GetFieldID(objectClass, "ProductType", "Ljava/lang/String;");
	jfieldID ProductNameFiledID = env->GetFieldID(objectClass, "ProductName", "Ljava/lang/String;");
	jfieldID IPAddressFiledID = env->GetFieldID(objectClass, "IPAddress", "Ljava/lang/String;");

//	jmethodID mIDCLientID = env->GetMethodID(objectClass, "SetID", "(I)V");
//	jmethodID mIDVendorName = env->GetMethodID(objectClass, "SetVendorName", "(Ljava/lang/String;)V");
//	jmethodID mIDProductType = env->GetMethodID(objectClass, "SetProductType", "(Ljava/lang/String;)V");
//	jmethodID mIDProductName = env->GetMethodID(objectClass, "SetProductName", "(Ljava/lang/String;)V");

	jstring vendor;
	jstring product;
	jstring type;
	jstring other;
	jstring IPAddr;

	jint i = 0;
	for(i = 0; i < iClientNum; i ++)
	{
//		env->CallVoidMethod(objectClass, mIDCLientID, i);
//		env->CallVoidMethod(objectClass, mIDVendorName, vendor);
//		env->CallVoidMethod(objectClass, mIDProductType, type);
//		env->CallVoidMethod(objectClass, mIDProductName, product);

		vendor = env->NewStringUTF((const char *)(pClientList->ClientCapab.VendorName));
		product = env->NewStringUTF((const char *)(pClientList->ClientCapab.ProductName));
		type = env->NewStringUTF((const char *)(pClientList->ClientCapab.ProductType));
		IPAddr = env->NewStringUTF((const char *)(pClientList->ClientIPAddr));

		jclass oClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");
		jobject Obj = env->AllocObject(oClass);
		env->SetIntField(Obj, ClientIDFiledID, pClientList->ClientID);
		env->SetObjectField(Obj, VendorNameFiledID, vendor);
		env->SetObjectField(Obj, ProductTypeFiledID, type);
		env->SetObjectField(Obj, ProductNameFiledID, product);
		env->SetObjectField(Obj, IPAddressFiledID, IPAddr);

		HWTEST_LOGD("i = %d", i);
		env->SetObjectArrayElement(ClientList, i, Obj);

		pClientList = pClientList->Next;
	}

	for (i = 0; i < env->GetArrayLength(ClientList); i ++)
	{
		jobject Obj = env->GetObjectArrayElement(ClientList, i);
		HWTEST_LOGD("Array : ClientID = %d", env->GetIntField(Obj, ClientIDFiledID));
	}

	HWTEST_LOGD("Leave Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo.");
	return ClientList;
}
#endif
#if 0
jobjectArray Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo(JNIEnv *env, jobject thiz)
{

	int iNum = 3;
	ClientInfo *pClientList = NULL;

	jclass objClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo.");

	jobjectArray ClientList = env->NewObjectArray((jsize)iNum, objClass, 0);

	jclass objectClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");

	if (NULL == objectClass)
	{
		HWTEST_LOGD("objectClass is null");
	}
	jfieldID ClientIDFiledID = env->GetFieldID(objectClass, "ClientID", "I");
	jfieldID VendorNameFiledID = env->GetFieldID(objectClass, "VendorName", "Ljava/lang/String;");
	jfieldID ProductTypeFiledID = env->GetFieldID(objectClass, "ProductType", "Ljava/lang/String;");
	jfieldID ProductNameFiledID = env->GetFieldID(objectClass, "ProductName", "Ljava/lang/String;");

//	jmethodID mIDCLientID = env->GetMethodID(objectClass, "SetID", "(I)V");
//	jmethodID mIDVendorName = env->GetMethodID(objectClass, "SetVendorName", "(Ljava/lang/String;)V");
//	jmethodID mIDProductType = env->GetMethodID(objectClass, "SetProductType", "(Ljava/lang/String;)V");
//	jmethodID mIDProductName = env->GetMethodID(objectClass, "SetProductName", "(Ljava/lang/String;)V");

	jstring vendor;
	jstring product;
	jstring type;
	jstring other;

	vendor = env->NewStringUTF("Mediatek");
	product = env->NewStringUTF("IoT device");
	type = env->NewStringUTF("MT7681");
	other = env->NewStringUTF("test");

	jint i = 0;
	for(i = 0; i < iNum - 1; i ++)
	{
//		env->CallVoidMethod(objectClass, mIDCLientID, i);
//		env->CallVoidMethod(objectClass, mIDVendorName, vendor);
//		env->CallVoidMethod(objectClass, mIDProductType, type);
//		env->CallVoidMethod(objectClass, mIDProductName, product);

		jclass oClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");
		jobject Obj = env->AllocObject(oClass);
		env->SetIntField(Obj, ClientIDFiledID, i);
		env->SetObjectField(Obj, VendorNameFiledID, vendor);
		env->SetObjectField(Obj, ProductTypeFiledID, type);
		env->SetObjectField(Obj, ProductNameFiledID, product);
		HWTEST_LOGD("i = %d", i);
		env->SetObjectArrayElement(ClientList, i, Obj);
	}

	jclass oClass = env->FindClass("mediatek/android/IoTManager/ClientInfo");
	jobject Obj = env->AllocObject(oClass);
	env->SetIntField(Obj, ClientIDFiledID, 3);
	env->SetObjectField(Obj, VendorNameFiledID, other);
	env->SetObjectField(Obj, ProductTypeFiledID, other);
	env->SetObjectField(Obj, ProductNameFiledID, other);
	env->SetObjectArrayElement(ClientList, i, Obj);


	for (i = 0; i < env->GetArrayLength(ClientList); i ++)
	{
		jobject Obj = env->GetObjectArrayElement(ClientList, i);
		HWTEST_LOGD("Array : ClientID = %d", env->GetIntField(Obj, ClientIDFiledID));
	}

	HWTEST_LOGD("Leave Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo.");
	return ClientList;
}
#endif

jint Java_mediatek_android_IoTManager_IoTManagerNative_ControlClientOffline(JNIEnv *env, jobject thiz, jint jClientID)
{
	int iRet = 0;
	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_ControlClientOffline.");
	iRet = CtrlClientOffline(jClientID);
	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_ControlClientOffline.");

	return iRet;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_SetGPIO(JNIEnv *env, jobject thiz, jint jClientID, jint GPIOList, jint GPIOValue)
{
	int iRst = 0;

	iRst = SetGPIO(jClientID, GPIOList, GPIOValue);

	return iRst;
}

jintArray Java_mediatek_android_IoTManager_IoTManagerNative_GetGPIO(JNIEnv *env, jobject thiz, jint jClientID)
{
	unsigned int GPIOList = 0;
	unsigned int GPIOValue = 0;
	int iRet = 0;
	int iArrayCount = 2;
	int GPIOInfo[2] = {0};

	jintArray GPIOResult = env->NewIntArray(iArrayCount);

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_GetGPIO.");
	iRet = GetGPIO(jClientID, &GPIOList, &GPIOValue);
//	GPIOList = 250;
//	GPIOValue = 224;

	GPIOInfo[0] = GPIOList;
	GPIOInfo[1] = GPIOValue;

	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_GetGPIO.");

//	env->SetIntArrayElement(GPIOResult, 0, (int)iGPIOMap);
//	env->SetIntArrayElement(GPIOResult, 1, GPIONumber);
	env->SetIntArrayRegion(GPIOResult, 0, 2, GPIOInfo);

	return GPIOResult;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_SetUARTData(JNIEnv *env, jobject thiz, jint jClientID,
						jstring jUartTxData, jint jLength)
{
	const char *pTxData = NULL;
	int iRet = 0;

	pTxData = env->GetStringUTFChars(jUartTxData, 0);

	iRet = SetUART(jClientID, pTxData, jLength);
	HWTEST_LOGD("UartTxData = %s \n", pTxData);

	return 0;
}

jstring Java_mediatek_android_IoTManager_IoTManagerNative_GetUARTData(JNIEnv *env, jobject thiz, jint jClientID)
{
	char UartRxData[512] = {};

	int iRet = 0;
	int iLen = 0;
	iRet = GetUART(jClientID, UartRxData, &iLen);
	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}

	return env->NewStringUTF(UartRxData);
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_SetPWM(JNIEnv *env, jobject thiz, jint jClientID, jshort jRed, jshort jGreen, jshort jBlue)
{
	int iRet = 0;
	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_SetPWM.");
	iRet = SetPWM(jClientID, jRed, jGreen, jBlue);
	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_SetPWM.");
	return iRet;
}

jintArray Java_mediatek_android_IoTManager_IoTManagerNative_GetPWM(JNIEnv *env, jobject thiz, jint jClientID)
{
	unsigned short int sGreen = 0;
	unsigned short int sRed = 0;
	unsigned short int sBlue = 0;
	int iRet = 0;
	int iArrayCount = 3;
	int PWMInfo[3] = {0};

	jintArray PWMResult = env->NewIntArray(iArrayCount);

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_GetPWM.");

	iRet = GetPWM(jClientID, &sRed, &sGreen, &sBlue);

	PWMInfo[0] = sRed;
	PWMInfo[1] = sGreen;
	PWMInfo[2] = sBlue;

	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_GetPWM.");

//	env->SetIntArrayElement(GPIOResult, 0, (int)iGPIOMap);
//	env->SetIntArrayElement(GPIOResult, 1, GPIONumber);
	env->SetIntArrayRegion(PWMResult, 0, 3, PWMInfo);

	return PWMResult;
}
jint Java_mediatek_android_IoTManager_IoTManagerNative_GetTEMP(JNIEnv *env, jobject thiz, jint jClientID)
{
	unsigned int iTemp=0;
	int iRet = 0;

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_GetTEMP.");

	iRet = GetTEMP(jClientID, &iTemp);

	if (iRet < 0)
	{
		HWTEST_LOGD("jClientID does not exist.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_GetTEMP.");



	return (jint)iTemp;
}

static int PasswordtoSeesionID(const char *pPassword)
{
	int iSessionID = 0xFFFFFFFF;

	if (NULL == pPassword)
	{
		return iSessionID;
	}

	if (0 == strlen(pPassword)|| strlen(pPassword) < 4)
	{
		HWTEST_LOGD("Use default Control Password");
		return iSessionID;
	}

	memcpy((char *)&iSessionID, pPassword, 4);
	HWTEST_LOGD("Session ID = 0x%x", iSessionID);

	return iSessionID;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_InitCtrlPassword(JNIEnv *env, jobject thiz, jstring jPassword)
{
	int iRet = 0;
	const char *pPassword = NULL;
	int iSessionID = 0xFFFFFFFF;

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_InitCtrlPassword");

	pPassword = env->GetStringUTFChars(jPassword, 0);
	HWTEST_LOGD("Init Control Password = [%s]", pPassword);
	iSessionID = PasswordtoSeesionID(pPassword);

	iRet = InitCtrlPassword(iSessionID);
	if (iRet < 0)
	{
		HWTEST_LOGD("Control password set error.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_InitCtrlPassword.");
	return iRet;
}

jint Java_mediatek_android_IoTManager_IoTManagerNative_AddFriend(JNIEnv *env, jobject thiz, jstring jFriendID)
{
	int iRet = 0;
	const char *FriendID = NULL;
//	int iSessionID = 0xFFFFFFFF;

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_AddFriend");

	FriendID = env->GetStringUTFChars(jFriendID, 0);
	HWTEST_LOGD("Init Control Password = [%s]", FriendID);

	iRet = AddFriend(FriendID);
	if (iRet < 0)
	{
		HWTEST_LOGD("Add Friend error.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_AddFriend.");
	return iRet;
}


jint Java_mediatek_android_IoTManager_IoTManagerNative_SetCtrlPassword(JNIEnv *env, jobject thiz, jstring jPassword)
{
	int iRet = 0;
	const char *pPassword = NULL;
	int iSessionID = 0xFFFFFFFF;

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_SetCtrlPassword");

	pPassword = env->GetStringUTFChars(jPassword, 0);
	iSessionID = PasswordtoSeesionID(pPassword);
	HWTEST_LOGD("Set Control Password = [%s]", pPassword);

	iRet = SetCtrlPassword(iSessionID);
	if (iRet < 0)
	{
		HWTEST_LOGD("Control password set error.");
	}
	HWTEST_LOGD("leavl Java_mediatek_android_IoTManager_IoTManagerNative_SetCtrlPassword.");
	return iRet;
}
#if 0
static JNINativeMethod mehods[] = {

		{ "StartSmartConnection", "(Ljava/lang/String;Ljava/lang/String;B)I",
			(void *) Java_mediatek_android_IoTManager_IoTManagerNative_StartSmartConnection },
		{ "StopSmartConnection", "()I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_StopSmartConnection },
		{ "InitControlServer", "(Ljava/lang/String;I)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_InitControlServer },
		{ "QueryClientInfo", "(I)[Lmediatek/android/IoTManager/ClientInfo;", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_QueryClientInfo },
		{ "CtrlClientOffline", "(I)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_ControlClientOffline },
		{ "SetGPIO", "(III)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_SetGPIO },
		{ "GetGPIO", "(I)[I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_GetGPIO },
		{ "SetUARTData", "(ILjava/lang/String;I)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_SetUARTData },
		{ "GetUARTData", "(I)Ljava/lang/String;", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_GetUARTData },
		{ "SetPWM", "(ISSS)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_SetPWM },
		{ "GetPWM", "(I)[I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_GetPWM },
		{ "SetCtrlPassword", "(Ljava/lang/String;)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_SetCtrlPassword },
		{ "InitCtrlPassword", "(Ljava/lang/String;)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_InitCtrlPassword },
		{ "AddFriend", "(Ljava/lang/String;)I", (void *) Java_mediatek_android_IoTManager_IoTManagerNative_AddFriend },

		};
// This function only registers the native methods
static int register_IoT_smartconnection(JNIEnv *env) {
	HWTEST_LOGE("Register: register_IoT_smartconnection()...\n");
	/*
	 JNINativeMethod nm;
	 nm.name = "doBtTest";
	 nm.signature = "(I)I";
	 nm.fnPtr = (void *)BtTest_doBtTest;
	 */
	HWTEST_LOGE("register_IoT_smartconnection");
	//return AndroidRuntime::registerNativeMethods(env,
			//"mediatek/android/IoTManager/IoTManagerNative", mehods, NELEM(mehods));
}

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	JNIEnv* env = NULL;
	jint result = -1;

	HWTEST_LOGD("Enter Java_mediatek_android_IoTManager_IoTManagerNative_OnLoad()...\n");
	if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
		HWTEST_LOGE("ERROR: GetEnv failed\n");
		goto bail;
	}
	assert(env != NULL);

	//if(registerNatives(env) != Java_mediatek_android_IoTManager_IoTManagerNative_TRUE)
	if (register_IoT_smartconnection(env) < 0) {
		HWTEST_LOGE("ERROR: JNI OnLoad register IoT_smartconnection failed\n");
		goto bail;
	}

	/* success -- return valid version number */
	result = JNI_VERSION_1_4;

	HWTEST_LOGD("Leave Java_mediatek_android_IoTManager_IoTManagerNative_OnLoad()...\n");
	bail: return result;
}
#endif
}
